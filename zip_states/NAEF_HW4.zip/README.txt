Homework 3 - Turner Naef

Building:

Try running: ./build.sh

If that doesn't work run: make && ./build/HW4

* My executable is named HW4 and located in the build directory

Usage:
UP/DOWN/RIGHT/LEFT = change view angles for ortho and perspective projections
UP/DOWN/RIGHT/LEFT = move forward, backwards and turn (LEFT/RIGHT) for first person view

W/S = change first person height (first person mode only)

esc key = quit the program

R/r = reset view angles
A/a = show or hide axes

1 = toggle the speeder object showcase

Description:
In this homework I attempted to recreate the Endor speeder chase scene from Star Wars Return of the Jedi.
I began by creating some basic trees for my enviroment along with "ground".
I then moved to the speeder which is the more complex object and took me the longest.
I chose to follow a more traditional object oriented approach here with the hopes that I will continue to work on this project.