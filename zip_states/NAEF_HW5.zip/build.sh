#!/bin/bash

# This script is used to run the endor(HW5) program
make

# Run the program
./build/HW5
