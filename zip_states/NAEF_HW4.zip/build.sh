#!/bin/bash

# This script is used to run the endor(HW3) program
make

# Run the program
./build/HW4
